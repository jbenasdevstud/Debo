import SwiftUI
import WebKit
import UIKit

/// Shows the Debo web app and gives it the same native helpers the Android app has
/// (window.AndroidReminders, AndroidPrint, AndroidFiles, AndroidUi, NativeFoodTools),
/// so app.js runs unchanged.
@MainActor
struct DeboWebView: UIViewRepresentable {
    let indexURL: URL

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WebContainer {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default() // keeps localStorage (all Debo data) between launches
        config.allowsInlineMediaPlayback = true
        config.dataDetectorTypes = []

        let controller = config.userContentController
        for name in Coordinator.messageNames {
            controller.add(context.coordinator, name: name)
        }
        controller.addUserScript(WKUserScript(source: Coordinator.bridgeScript(barcode: BarcodeScanner.isAvailable, lock: AppLock.isAvailable, lockOn: AppLock.shared.enabled),
                                              injectionTime: .atDocumentStart,
                                              forMainFrameOnly: true))
        // iOS-only page tweaks (Web/ios-native.js)
        let pageScript = (try? String(contentsOf: indexURL.deletingLastPathComponent().appendingPathComponent("ios-native.js"),
                                      encoding: .utf8)) ?? ""
        controller.addUserScript(WKUserScript(source: pageScript,
                                              injectionTime: .atDocumentEnd,
                                              forMainFrameOnly: true))

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = false
        webView.allowsLinkPreview = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0xF5 / 255, green: 0xF7 / 255, blue: 0xF4 / 255, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        // No rubber-band bounce when there is nothing to scroll (e.g. while a window is open)
        webView.scrollView.alwaysBounceVertical = false
        webView.scrollView.alwaysBounceHorizontal = false
        context.coordinator.webView = webView
        context.coordinator.indexURL = indexURL
        context.coordinator.watchResume()
        Reminders.shared.setUp()
        AppLock.shared.start()

        let container = WebContainer(webView: webView)
        context.coordinator.container = container
        webView.loadFileURL(indexURL, allowingReadAccessTo: indexURL.deletingLastPathComponent())
        return container
    }

    func updateUIView(_ uiView: WebContainer, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
        weak var webView: WKWebView?
        weak var container: WebContainer?
        var indexURL: URL?
        private var resumeObserver: NSObjectProtocol?
        private var pingCount = 0
        private var awaitingPing = 0
        private var printView: WKWebView?
        private var printTitle = "Debo"
        private var lastThemeDark: Bool?

        static let messageNames = ["deboPrint", "deboSaveFile", "deboReminder", "deboTheme", "deboBarcode", "deboLock", "deboSteps", "deboHaptic", "deboAppLock"]

        static func bridgeScript(barcode: Bool, lock: Bool, lockOn: Bool) -> String {
            """
            (function () {
              var post = function (name, body) { window.webkit.messageHandlers[name].postMessage(body); };
              window.AndroidPrint = {
                print: function (html, title) { post('deboPrint', { html: String(html), title: String(title || 'Debo') }); }
              };
              window.AndroidFiles = {
                saveText: function (name, mime, text) { post('deboSaveFile', { name: String(name), text: String(text) }); }
              };
              window.AndroidUi = {
                setTheme: function (theme) { post('deboTheme', { theme: String(theme) }); }
              };
              window.AndroidReminders = {
                schedule: function (id, at, title, body) {
                  post('deboReminder', { action: 'schedule', id: id, at: at, interval: 0, title: String(title), body: String(body) });
                },
                scheduleRepeating: function (id, at, interval, title, body) {
                  post('deboReminder', { action: 'schedule', id: id, at: at, interval: interval, title: String(title), body: String(body) });
                },
                scheduleRepeatingQuiet: function (id, at, interval, title, body, quietFrom, quietTo) {
                  post('deboReminder', { action: 'schedule', id: id, at: at, interval: interval, title: String(title), body: String(body), quietFrom: quietFrom, quietTo: quietTo });
                },
                cancel: function (id) { post('deboReminder', { action: 'cancel', id: id }); }
              };
              window.DeboSteps = { load: function () { post('deboSteps', {}); } };
              window.DeboHaptic = function (kind) { post('deboHaptic', { kind: String(kind || 'light') }); };
              \(lock ? "window.DeboLock = { enabled: \(lockOn), set: function (on) { post('deboAppLock', { enabled: !!on }); } };" : "")
              \(barcode ? "window.NativeFoodTools = { scanBarcode: function () { post('deboBarcode', {}); } };" : "")
            })();
            """
        }

        // MARK: JS -> Swift

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            let body = message.body as? [String: Any] ?? [:]
            switch message.name {
            case "deboPrint":
                printReport(html: body["html"] as? String ?? "", title: body["title"] as? String ?? "Debo")
            case "deboSaveFile":
                saveFile(name: body["name"] as? String ?? "debo.json", text: body["text"] as? String ?? "")
            case "deboReminder":
                Reminders.shared.handle(body)
            case "deboTheme":
                let dark = (body["theme"] as? String) == "dark"
                lastThemeDark = dark
                webView?.window?.overrideUserInterfaceStyle = dark ? .dark : .light
                let color = dark
                    ? UIColor(red: 0x14 / 255, green: 0x1A / 255, blue: 0x19 / 255, alpha: 1)
                    : UIColor(red: 0xF5 / 255, green: 0xF7 / 255, blue: 0xF4 / 255, alpha: 1)
                webView?.backgroundColor = color
                webView?.scrollView.backgroundColor = color
                container?.backgroundColor = color
            case "deboBarcode":
                scanBarcode()
            case "deboSteps":
                Steps.shared.load { [weak self] json in
                    self?.callJS("window.onDeboSteps && window.onDeboSteps(\(json))")
                }
            case "deboHaptic":
                if (body["kind"] as? String) == "success" {
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                } else {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                }
            case "deboAppLock":
                AppLock.shared.setEnabled((body["enabled"] as? Bool) == true) { [weak self] on in
                    self?.callJS("window.onDeboLock && window.onDeboLock(\(on))")
                }
            case "deboLock":
                container?.pinScroll = (body["locked"] as? Bool) == true
            default:
                break
            }
        }

        // MARK: Doctor report

        private func printReport(html: String, title: String) {
            // A separate web view renders the report exactly as on screen (charts included)
            let view = WKWebView(frame: CGRect(x: 0, y: 0, width: 800, height: 1100))
            view.navigationDelegate = self
            printView = view
            printTitle = title
            view.loadHTMLString(html, baseURL: nil)
        }

        private func showPrintDialog(for view: WKWebView) {
            let info = UIPrintInfo(dictionary: nil)
            info.jobName = printTitle
            info.outputType = .general
            let controller = UIPrintInteractionController.shared
            controller.printInfo = info
            controller.printFormatter = view.viewPrintFormatter()
            let done: UIPrintInteractionController.CompletionHandler = { [weak self] _, _, _ in self?.printView = nil }
            if let host = webView, UIDevice.current.userInterfaceIdiom == .pad {
                let rect = CGRect(x: host.bounds.midX, y: host.bounds.midY, width: 1, height: 1)
                controller.present(from: rect, in: host, animated: true, completionHandler: done)
            } else {
                controller.present(animated: true, completionHandler: done)
            }
        }

        // MARK: Backup export

        private func saveFile(name: String, text: String) {
            let safeName = name.replacingOccurrences(of: "/", with: "-")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            do {
                try text.write(to: url, atomically: true, encoding: .utf8)
            } catch {
                callJS("window.onFileSaved && window.onFileSaved('error')")
                return
            }
            let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            sheet.completionWithItemsHandler = { [weak self] _, completed, _, error in
                let result = error != nil ? "error" : (completed ? "ok" : "cancel")
                self?.callJS("window.onFileSaved && window.onFileSaved('\(result)')")
            }
            present(sheet)
        }

        // MARK: Barcode

        private func scanBarcode() {
            let scanner = BarcodeScanner { [weak self] code in
                guard let self else { return }
                if let code {
                    let digits = code.filter(\.isNumber)
                    self.callJS("window.onNativeBarcodeScanned && window.onNativeBarcodeScanned('\(digits)')")
                }
                // Cancelled: the manual EAN field stays open
            }
            if !present(scanner.makeController()) {
                callJS("window.onNativeBarcodeError && window.onNativeBarcodeError()")
            }
        }

        // MARK: Navigation, links, alerts

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            if webView === printView {
                showPrintDialog(for: webView)
            } else if let dark = lastThemeDark {
                // The first theme message can arrive before the view is in a window
                webView.window?.overrideUserInterfaceStyle = dark ? .dark : .light
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // Web links (privacy policy, Open Food Facts, …) open in Safari; the app's own files stay inside
            if webView !== printView,
               let url = navigationAction.request.url,
               let scheme = url.scheme?.lowercased(),
               ["http", "https", "mailto", "tel"].contains(scheme),
               navigationAction.navigationType == .linkActivated || navigationAction.targetFrame?.isMainFrame == true {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url { UIApplication.shared.open(url) }
            return nil
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            if webView === printView { printView = nil } else { reloadPage() }
        }

        // MARK: Coming back to the app

        /// iOS may stop the page while Debo is in the background. Coming back, check that it still
        /// answers, and load it again if not, so the app never stays frozen.
        func watchResume() {
            guard resumeObserver == nil else { return }
            resumeObserver = NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification,
                                                                    object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.checkPageAlive() }
            }
        }

        private func checkPageAlive() {
            guard let webView else { return }
            pingCount += 1
            let ping = pingCount
            awaitingPing = ping
            webView.evaluateJavaScript("1") { [weak self] _, error in
                guard let self else { return }
                if self.awaitingPing == ping { self.awaitingPing = 0 }
                if error != nil { self.reloadPage() }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
                guard let self, self.awaitingPing == ping else { return }
                self.awaitingPing = 0
                self.reloadPage()
            }
        }

        private func reloadPage() {
            guard let webView else { return }
            if webView.url == nil, let indexURL {
                webView.loadFileURL(indexURL, allowingReadAccessTo: indexURL.deletingLastPathComponent())
            } else {
                webView.reload()
            }
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            if !present(alert) { completionHandler() }
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
            if !present(alert) { completionHandler(false) }
        }

        // MARK: Helpers

        private func callJS(_ script: String) {
            DispatchQueue.main.async { self.webView?.evaluateJavaScript(script, completionHandler: nil) }
        }

        @discardableResult
        private func present(_ controller: UIViewController) -> Bool {
            guard var top = webView?.window?.rootViewController else { return false }
            while let next = top.presentedViewController { top = next }
            if let popover = controller.popoverPresentationController, let view = webView {
                popover.sourceView = view
                popover.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
                popover.permittedArrowDirections = []
            }
            top.present(controller, animated: true)
            return true
        }
    }
}
